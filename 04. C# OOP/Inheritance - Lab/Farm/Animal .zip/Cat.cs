﻿using System;
using System.Collections.Generic;
using System.Net.WebSockets;
using System.Text;

namespace Farm
{
    public class Cat : Animal
    {

        public void Meow()
        {
            Console.WriteLine("meowing…");      
        }
    }
}
